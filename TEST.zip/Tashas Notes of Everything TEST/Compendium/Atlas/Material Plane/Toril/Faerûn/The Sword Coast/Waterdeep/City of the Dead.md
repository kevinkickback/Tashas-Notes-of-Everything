---
cssClasses: grayTable, wideTable
type: landmark
locations:
- "[[Waterdeep]]"
tags:
- location/cemetery
headerLink: "[[City of the Dead#City of the Dead]]"
---

![[cityDead.webp|banner]]
###### City of the Dead
<span class="sub2">:FasGhost: Cemetery</span>
___

> [!quote|no-t] SUMMARY
>The City of the Dead isa large cemetery and ward in [[Waterdeep#Waterdeep]]. Most of the city's dead are buried here. By day, it also doubles as the city's major public park picnic area.
<span class="clearfix"></span>

#### marker
> [!column|flex 3]
> > [!hint]-  NPC's
> >```dataview
LIST WITHOUT ID headerLink
FROM "Compendium/NPC's" AND [[City of the Dead]]
SORT file.name ASC
> 
>> [!note]- HISTORY
>>```dataview
LIST WITHOUT ID headerLink
FROM "Session Notes" AND [[City of the Dead]]
SORT file.ctime DESC