---
type: npc
locations:
- "[[Feywild]]"
tags:
- race/fairy
- affinity/unknown
- job/rebellionLeader
headerLink: "[[Eleidin Verlice#Eleidin Verlice]]"
---
###### Eleidin Verlice
<span class="sub2">:FasMapLocationDot: [[Feywild#Feywild]] &nbsp; | &nbsp; :FasHeartPulse: Unknown </span>
___

> [!infobox|no-t right]
> ![[eleidin.jpg]]
> ###### Details:
> | Type | Stat |
> | ---- | ---- |
> | :FasBriefcase: Job | Rebellion Leader |
> | :FasVenusMars: Gender | Male |
> | :FasUser: Race | Fairy |
<span class="clearfix"></span>

> [!quote|no-t]
>Eleidin Verlice commands attention with his luminous wings and piercing gaze. As the leader of a burgeoning rebellion, he exudes an aura of determination and resilience. His every movement resonates with an air of authority, drawing followers to his cause like moths to a flame. Beneath his serene exterior lies a fierce determination to challenge the status quo and pave the way for a new era of freedom in the enchanted realms.

#### marker
> [!column|flex 3]
>> [!important]- QUESTS:
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Compendium/Party/Quests" AND [[Eleidin Verlice]]
>
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Eleidin Verlice]]