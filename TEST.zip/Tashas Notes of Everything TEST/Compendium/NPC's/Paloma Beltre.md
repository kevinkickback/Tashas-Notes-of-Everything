---
type: npc
locations:
- "[[Elfsong Tavern]]"
tags:
- race/half-Elf
- affinity/friendly
- job/waitress
headerLink: "[[Paloma Beltre#Paloma Beltre]]"
---
###### Paloma Beltre
<span class="sub2">:FasMapLocationDot: [[Elfsong Tavern#Elfsong Tavern]] &nbsp; | &nbsp; :FasHeartPulse: Neutral </span>
___

> [!infobox|no-t right]
> ![[paloma.jpg]]
> ###### Details:
> | Type | Stat |
> | ---- | ---- |
> | :FasBriefcase:  Job | Waitress |
> | :FasVenusMars: Gender | Female |
> | :FasUser: Race | Half-Elf |
<span class="clearfix"></span>

> [!quote|no-t]
> Paloma Beltre, a half-elf of graceful bearing, captivates patrons of the ElfSong Tavern with her ethereal beauty and warm demeanor. Her elven heritage is evident in her pointed ears and striking features, softened by a hint of human ancestry. As a waitress, she glides effortlessly between tables, her movements fluid and precise, always wearing a welcoming smile. Despite her modest occupation, Paloma exudes an air of mystery, leaving patrons intrigued by the secrets she might hold within her enigmatic gaze.

#### marker
> [!column|flex 3]
>> [!important]- QUESTS:
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Compendium/Party/Quests" AND [[Paloma Beltre]]
>
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Paloma Beltre]]