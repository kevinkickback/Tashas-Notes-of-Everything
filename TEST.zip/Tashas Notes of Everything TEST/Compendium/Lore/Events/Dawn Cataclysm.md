---
type: event
tags:
- event/religious
headerLink: "[[Dawn Cataclysm#Dawn Cataclysm]]"
---

###### Dawn Cataclysm
<span class="sub2">:FasCross: Religious Event</span>
___

> [!quote|no-t]
>![[dawncataclysm.jpg|right wm-sm]]The Dawn Cataclysm was an attempt by the god [[Lathander#Lathander]] to reshape the pantheon of deities more in his own image. It is unknown when this event occurred but it ultimately failed, resulting in the destruction of several deities (e.g. [[Tyche#Tyche]] splitting into [[Tymora#Tymora]] and [[Beshaba#Beshaba]]).
<span class="clearfix"></span>

#### marker
> [!column|flex 3]
>>[!hint]- NPC's
>>```dataview
>>LIST WITHOUT ID headerLink
>FROM "Compendium/NPC's" AND [[Dawn Cataclysm]]
>
>>[!note]- HISTORY
>>```dataview
>LIST WITHOUT ID headerLink
>FROM "Session Notes" AND [[Dawn Cataclysm]]