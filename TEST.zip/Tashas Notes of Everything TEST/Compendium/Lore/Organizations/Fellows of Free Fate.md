---
type: organization
locations:
-
tags:
- 
headerLink: "[[Fellows of Free Fate#Fellows of Free Fate]]"
---

###### Fellows of Free Fate
<span class="sub2">:FasCross: Religious Organization</span>
___

> [!quote|no-t]
>![[triff.jpg|right wm-tl]]The Fellows of Free Fate, known locally as the Triffs, is a sect of [[Tymora#Tymora|Tymoran]] clergy who dedicate themselves to fight against the actions of [[Beshaba#Beshaba|Beshaban]] followers, specifically the [[Black Fingers#The Black Fingers|Black Fingers]].

#### marker
> [!column|flex 3]
>>[!hint]- NPC's
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Compendium/NPC's" AND [[Fellows of Free Fate]]
>
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Fellows of Free Fate]]