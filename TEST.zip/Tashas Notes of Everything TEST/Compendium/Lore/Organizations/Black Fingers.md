---
type: organization
locations:
  - 
tags:
  - 
headerLink: "[[Black Fingers#The Black Fingers]]"
---

###### The Black Fingers
<span class="sub2">:FasCross: Religious Organization</span>
___

> [!quote|no-t]
>![[blackfinger.jpg|right wm-sm]]A secret society of assassins  devoted to the goddess [[Beshaba#Beshaba]] a.k.a the "Maiden of Misfortune". Comprising predominantly of male clergy, seasoned warriors, and cunning thieves, the group operates in the shadows, executing deadly missions with precision. Cloaked in secrecy, their loyalty to Bashaba binds them to a code of silence, adding an air of mystery to their enigmatic existence. The Black Fingers thrive on chaos, spreading misfortune to achieve their divine purpose and leaving an ominous mark on those who encounter their lethal touch.
<span class="clearfix"></span>

#### marker
> [!column|flex 3]
>>[!hint]- NPC's
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Compendium/NPC's" AND [[Black Fingers]]
>
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Black Fingers]]