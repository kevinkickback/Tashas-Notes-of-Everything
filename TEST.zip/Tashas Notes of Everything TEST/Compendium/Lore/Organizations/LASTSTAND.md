---
type: organization
locations:
-
tags:
- 
headerLink: "[[LASTSTAND#LASTSTAND]]"
---

###### LASTSTAND
<span class="sub2">:FasPeopleGroup: Adventuring Party</span>
___

> [!quote|no-t]
>![[laststand.jpg|right wm-tl]]Last Stand, stylized as **LASTSTAND**, is an adventuring group comprised of party members [[Kingston Yashkar#Kingston Yashkar|Kingston]], [[Moira Belkas#Moira Belkas|Moira]], [[Alaric Waycrest#Alaric Waycrest|Alaric]], and [[Tilda Rosesong#Tilda Rosesong|Tilda]].

#### marker
> [!column|flex 3]
>> [!info]- STORYLINES:
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Compendium/Party/Quests"
>>WHERE target = "groupQuest"
>>SORT file.ctime DESC
>
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[LASTSTAND]]