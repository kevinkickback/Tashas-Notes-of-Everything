---
type: object
tags:
- artifact
headerLink: "[[The Scarlet Scourge#The Scarlet Scourge]]"
---

###### The Scarlet Scourge
<span class="sub2">:FasCross: Religious Artifact</span>
___

> [!quote|no-t]
>![[scarletScourge.png|right ws-med]]This whip is made from the severed vertebrae of a slain victims. Said to be created by [[Beshaba#Beshaba]] herself, this weapon has been handed down through generations to elite members of [[Black Fingers#The Black Fingers]].
<span class="clearfix"></span>

#### marker
#### marker
> [!column|flex 3]
>>[!hint]- NPC's
>>```dataview
>>LIST WITHOUT ID headerLink
>FROM "Compendium/NPC's" AND [[The Scarlet Scourge]]
>
>>[!note]- HISTORY
>>```dataview
>LIST WITHOUT ID headerLink
>FROM "Session Notes" AND [[The Scarlet Scourge]]