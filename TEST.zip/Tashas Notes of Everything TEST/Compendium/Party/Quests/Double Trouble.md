---
type: quest
target: "[[Alaric Waycrest]]"
locations:
- 
tags:
- quest/pending
headerLink: "[[Double Trouble#Double Trouble]]"
---
###### Double Trouble
<span class="sub2">:FasCircleExclamation: Quest &nbsp; | &nbsp; :FasListCheck: Pending </span>
___

> [!quote|no-t]
>![[quest.png|right wm-sm]] Is a dark secret is being kept from the group...?

#### marker
> [!column|flex 3]
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Double Trouble]]

