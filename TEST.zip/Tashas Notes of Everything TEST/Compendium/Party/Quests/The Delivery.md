---
type: quest
target: groupQuest
locations:
- "[[Sorcerous Sundries]]"
tags:
- quest/ongoing
headerLink: "[[The Delivery#The Delivery]]"
---
###### The Delivery
<span class="sub2">:FasCircleExclamation: Quest &nbsp; | &nbsp; :FasListCheck: Ongoing &nbsp;  | &nbsp; :FasUser: [[Tinkera Drenn#Tinkera Drenn]]</span>
___

> [!quote|no-t]
>![[quest.png|right wm-sm]]Tinkera asks [[LASTSTAND#LASTSTAND]] to deliver a package to a secluded cottage on the outskirts of Baldur's Gate. She explains that the recipient, an old friend of hers, is expecting the delivery urgently. 
>#### marker
>**UPDATES:**
>-  *<span style="color: var(--link-color)">Day 05:</span>* arrive at the cottage to find [[Rythe Sterling#Rythe Sterling|Rythe]] creeping around
>-  *<span style="color: var(--link-color)">Day 02:</span>* package temporarily lost in scuffle with bandits on the road

#### marker
> [!column|flex 3]
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[The Delivery]]

