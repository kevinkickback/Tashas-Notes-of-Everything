---
type: quest
target: groupQuest
locations:
- "[[Baldurs Gate]]"
tags:
- quest/completed
headerLink: "[[Take Five#Take Five]]"
---
###### Take Five
<span class="sub2">:FasCircleExclamation: Quest &nbsp; | &nbsp; :FasListCheck: Completed </span>
___

> [!quote|no-t]
>![[quest.png|right wm-sm]]After returning home, the members of LASTSTAND decide to take some well deserved personal time... But what will they do?

#### marker
> [!column|flex 3]
>>[!note]- HISTORY
>>```dataview
>>LIST WITHOUT ID headerLink
>>FROM "Session Notes" AND [[Take Five]]

